package com.stockmarket.data.stockmarket.util;

import com.stockmarket.data.stockmarket.parameters.StockDataParameter;

//import javax.validation.constraints.Null;

public class StockDataParameterBuilder {
	
	private StringBuilder urlBuilder;

	public StockDataParameterBuilder() {
		super();
		this.urlBuilder = new StringBuilder();
	}
	
	public void append(StockDataParameter apiParameter) {
	    if (apiParameter != null) {
	      buildUrl(apiParameter.getKey(), apiParameter.getValue());
	    }
	  }

	public void buildUrl(String key, String value) {
		// TODO Auto-generated method stub
		String parameter = "&" + key + "=" + value;
	    this.urlBuilder.append(parameter);
		
	}
	
	public String getUrlBuilder() {
		return urlBuilder.toString();
	}

}
