package com.stockmarket.data.stockmarket.connector.impl;

import org.springframework.stereotype.Component;

import com.stockmarket.data.stockmarket.connector.StockApiConnector;
import com.stockmarket.data.stockmarket.parameters.StockDataParameter;
import com.stockmarket.data.stockmarket.util.StockDataParameterBuilder;

@Component
public class StockApiConnectorImpl implements StockApiConnector {

	  /* demo APi key is for demo purposes only. Not able to retrieve data using it hence generating own api key below */ 
	 //private final String apiKey="demo";
	 
	 private final String apiKey="O9HH3R61DVW3WVEZ";

	@Override
	public String getConnection(StockDataParameter... dataParameters) {
		// TODO Auto-generated method stub
		String params = getParameters(dataParameters);
		
		return params;
	}

	private String getParameters(StockDataParameter... dataParameters) {
		// TODO Auto-generated method stub
		 StockDataParameterBuilder urlBuilder = new StockDataParameterBuilder();
		    for (StockDataParameter parameter : dataParameters) {
		      urlBuilder.append(parameter);
		    }
		    urlBuilder.buildUrl("apikey", apiKey);
		    return urlBuilder.getUrlBuilder();
	}

}
