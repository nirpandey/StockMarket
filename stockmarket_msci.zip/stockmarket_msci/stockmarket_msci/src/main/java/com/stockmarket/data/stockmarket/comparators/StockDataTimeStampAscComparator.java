package com.stockmarket.data.stockmarket.comparators;

import java.util.Comparator;

import com.stockmarket.data.stockmarket.model.StockData;

public class StockDataTimeStampAscComparator implements Comparator<StockData> {

	@Override
	public int compare(StockData s1, StockData s2) {
		// TODO Auto-generated method stub
		return (s1.getDateTime().compareTo(s2.getDateTime()));
	}

}
