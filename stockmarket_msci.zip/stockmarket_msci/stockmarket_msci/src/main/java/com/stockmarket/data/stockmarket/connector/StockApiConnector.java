package com.stockmarket.data.stockmarket.connector;

import com.stockmarket.data.stockmarket.parameters.StockDataParameter;

public interface StockApiConnector {
	
	public String getConnection(StockDataParameter...dataParameters);

}	
