package com.stockmarket.data.stockmarket.request;

import com.stockmarket.data.stockmarket.parameters.StockDataParameter;

public enum StockService implements StockDataParameter {
	TIME_SERIES_INTRADAY("TIME_SERIES_INTRADAY");
	
	private final String stockServiceName;
	
	StockService(String serviceName){
		this.stockServiceName = serviceName;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return "function";
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return stockServiceName;
	}

}
