package com.stockmarket.data.stockmarket.parser;

import java.lang.reflect.Type;
import java.util.Map;

import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

public abstract class AbstractJsonParser<Data> extends JsonFileParser<Data> {

	@Override
	protected Data resolve(JsonObject rootObject) {
		// TODO Auto-generated method stub
		Type metaDataType = new TypeToken<Map<String, String>>() {
	    }.getType();
	    Type dataType = new TypeToken<Map<String, Map<String, String>>>() {
	    }.getType();
	    Map<String, String> metaData=null;
	    Map<String, Map<String, String>> stockData=null;
	    try {
	      metaData = GSON.fromJson(rootObject.get("Meta Data"), metaDataType);
	      stockData = GSON.fromJson(rootObject.get(getStockDataKey()), dataType);
	      resolve(metaData, stockData);
	    } catch (JsonSyntaxException e) {
	      e.printStackTrace();
	    }
	    return resolve(metaData, stockData);
	}

	abstract String getStockDataKey();

	abstract Data resolve(Map<String, String> metaData, Map<String, Map<String, String>> stockData);
}