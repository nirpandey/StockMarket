package com.stockmarket.data.stockmarket.parser;

import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

@Component
public abstract class JsonFileParser<Data> {
	
	protected final DateTimeFormatter SIMPLE_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	protected final DateTimeFormatter DATE_WITH_TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	protected final DateTimeFormatter DATE_WITH_SIMPLE_TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
	
	 private static com.google.gson.JsonParser PARSER = new com.google.gson.JsonParser();

	  /**
	   * Helper object to interpret the json.
	   * @see Gson
	   */
	  protected static Gson GSON = new Gson();
	  
	  protected abstract Data resolve(JsonObject rootObject);

	public Data parseJson(String jsonData) {
		// TODO Auto-generated method stub
		
		JsonObject rootObject = null;
		try {
		      JsonElement jsonElement = PARSER.parse(jsonData);
		      rootObject = jsonElement.getAsJsonObject();

		      JsonElement errorMessage = rootObject.get("Error Message");
		      if (errorMessage != null) {
		        throw new Exception(errorMessage.getAsString());
		      }

		      return resolve(rootObject);

		    }catch (Exception e) {
			  //throw new AlphaVantageException("error parsing json", e);
				 e.printStackTrace();
			}
			return resolve(rootObject);
		
		
	}
	  
	  

}
