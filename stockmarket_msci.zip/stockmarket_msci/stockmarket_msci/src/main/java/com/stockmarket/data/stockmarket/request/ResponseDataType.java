package com.stockmarket.data.stockmarket.request;

import com.stockmarket.data.stockmarket.parameters.StockDataParameter;

public enum ResponseDataType implements StockDataParameter {
	JSON("json"),
	CSV("csv");
	
	private final String dataType;
	

	ResponseDataType(String dataType) {
		this.dataType = dataType;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return "datatype";
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return dataType;
	}

}
