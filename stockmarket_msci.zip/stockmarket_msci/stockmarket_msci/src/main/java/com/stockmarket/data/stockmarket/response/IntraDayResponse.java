package com.stockmarket.data.stockmarket.response;

import java.util.List;
import java.util.Map;

import com.stockmarket.data.stockmarket.model.StockData;

public class IntraDayResponse extends ApiTimeSeriesResponse {

	public IntraDayResponse(Map<String, String> metaData, List<StockData> stockData) {
		super(metaData, stockData);
	}

}
