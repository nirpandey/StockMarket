package com.stockmarket.data.stockmarket.comparators;

import java.util.Comparator;

import com.stockmarket.data.stockmarket.model.StockData;

public class StockDataTimeStampDscComparator implements Comparator<StockData> {

	@Override
	public int compare(StockData s1, StockData s2) {
		// TODO Auto-generated method stub
		if((s1.getDateTime().compareTo(s2.getDateTime())) > 0){
		return s1.getDateTime().compareTo(s2.getDateTime());
		}else
		return s2.getDateTime().compareTo(s1.getDateTime());
	}

}
