package com.stockmarket.data.stockmarket.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.stockmarket.data.stockmarket.comparators.StockDataTimeStampDscComparator;
import com.stockmarket.data.stockmarket.controller.StockDataController;
import com.stockmarket.data.stockmarket.comparators.StockDataTimeStampAscComparator;
import com.stockmarket.data.stockmarket.model.StockData;
import com.stockmarket.data.stockmarket.parser.IntraDayParser;
import com.stockmarket.data.stockmarket.request.TimeInterval;
import com.stockmarket.data.stockmarket.response.IntraDayResponse;

@Component
public class IntraDayOpsUtility {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(IntraDayOpsUtility.class);
	
	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in)); 
	
	public IntraDayResponse parse(TimeInterval interval, String jsonData) {
		// TODO Auto-generated method stub
		IntraDayParser parser = new IntraDayParser(interval);
	    return parser.parseJson(jsonData);
	}
	
	public List<StockData> displayStockData(IntraDayResponse intraDayResponse) {
		// TODO Auto-generated method stub
		Map<String,String> treeMap = intraDayResponse.getMetaData();
		System.out.println("Details of the Stock:");
		for(Entry<String, String> entry : treeMap.entrySet()) {
			  String key = entry.getKey();
			  String value = entry.getValue();
			  
			  System.out.print(key + " => " + value+" "+"|"+" ");
			}
		System.out.println();
		System.out.println();
		List<StockData> list =intraDayResponse.getStockData();
		return displayStockListData(list);
			
	}

	private List<StockData> displayStockListData(List<StockData> list) {
		// TODO Auto-generated method stub
		System.out.printf("%-30s %-30s %-30s %-30s %-30s %-30s","Timestamp","Open","High","Low","Close","Volume");
		System.out.println();
		for(StockData stock : list){
			stock.display();
		}
		return list;
	}

	public void sort(List<StockData> list) {
		// TODO Auto-generated method stub
		List<StockData> listForExit = list;
		System.out.println("Please enter one of the following in order to get the sorted output: 1. 'Timestamp-Asc' 2. 'Timestamp-Desc'");
		   
           try {
			String sortingParameter = reader.readLine();
			if(sortingParameter.equalsIgnoreCase("Timestamp-Asc")){
				Collections.sort(list, new StockDataTimeStampAscComparator());
				displayStockListData(list);
			} 
			else if(sortingParameter.equalsIgnoreCase("Timestamp-Desc")){
				Collections.sort(list, new StockDataTimeStampDscComparator());
				displayStockListData(list);
			}
		askForExit(listForExit);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	private void askForExit(List<StockData> list) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("If you wish to exit this application, please enter exit else you can resort the values by typing 'Run Again'");
		String exit = reader.readLine();
		if(exit.equalsIgnoreCase("exit")){
			LOGGER.info("Exiting the programme. Stopping the JVM Instance!");
			System.exit(0);
		}
		else if(exit.equalsIgnoreCase("Run Again"))
			sort(list);
			
	}

}
