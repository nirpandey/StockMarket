package com.stockmarket.data.stockmarket.request;

import com.stockmarket.data.stockmarket.parameters.StockDataParameter;

public enum OutputSize implements StockDataParameter {
	COMPACT("compact"),
	FULL("full");
	
	private final String outputSize;
	
	

	OutputSize(String outputSize) {
		this.outputSize = outputSize;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return "outputsize";
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return outputSize;
	}

}
