package com.stockmarket.data.stockmarket.response;

import java.util.List;
import java.util.Map;

import com.stockmarket.data.stockmarket.model.StockData;

public class ApiTimeSeriesResponse {

	private final Map<String, String> metaData;
	  private final List<StockData> stockData;

	   ApiTimeSeriesResponse(final Map<String, String> metaData, final List<StockData> stockData) {
	    this.stockData = stockData;
	    this.metaData = metaData;
	  }

	  public Map<String, String> getMetaData() {
	    return metaData;
	  }

	 
	  public List<StockData> getStockData() {
	    return stockData;
	  }
}
