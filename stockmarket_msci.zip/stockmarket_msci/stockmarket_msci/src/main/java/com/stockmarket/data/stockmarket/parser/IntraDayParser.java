package com.stockmarket.data.stockmarket.parser;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.stockmarket.data.stockmarket.model.StockData;
import com.stockmarket.data.stockmarket.request.TimeInterval;
import com.stockmarket.data.stockmarket.response.IntraDayResponse;

public class IntraDayParser extends AbstractJsonParser<IntraDayResponse> {
	
	private TimeInterval interval;

	public IntraDayParser(TimeInterval interval) {
		// TODO Auto-generated constructor stub
		this.interval=interval;
	}

	@Override
    String getStockDataKey() {
      return "Time Series (" + interval.getValue() + ")";
    }

    @Override
    IntraDayResponse resolve(Map<String, String> metaData,
                     Map<String, Map<String, String>> stockData)  {
      List<StockData> stocks = new ArrayList<>();
      try {
        stockData.forEach((key, values) -> stocks.add(new StockData(
                LocalDateTime.parse(key, DATE_WITH_TIME_FORMAT),
                Double.parseDouble(values.get("1. open")),
                Double.parseDouble(values.get("2. high")),
                Double.parseDouble(values.get("3. low")),
                Double.parseDouble(values.get("4. close")),
                Long.parseLong(values.get("5. volume"))
        )));
      } catch (Exception e) {
        e.printStackTrace();
      }
      return new IntraDayResponse(metaData, stocks);
    }

}
