package com.stockmarket.data.stockmarket.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockmarket.data.stockmarket.request.OutputSize;
import com.stockmarket.data.stockmarket.request.StockName;
import com.stockmarket.data.stockmarket.request.StockService;
import com.stockmarket.data.stockmarket.request.TimeInterval;
import com.stockmarket.data.stockmarket.service.StockDataService;

@RestController
@RequestMapping("stockData")
public class StockDataController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StockDataController.class);
	
	@Autowired
	private StockDataService stockDataService;
	
	@GetMapping("fetch")
	public void getStockData(){
		LOGGER.info("Entering : getStockData ",System.currentTimeMillis());
		stockDataService.fetchStockData(new StockName("MSFT"),StockService.TIME_SERIES_INTRADAY, TimeInterval.FIVE_MIN, OutputSize.COMPACT);
		LOGGER.info("Completed : getStockData ",System.currentTimeMillis());
	}
	
	@GetMapping("fetch/{stockName}")
	public void getStockDataForEntity(@PathVariable("stockName") String stockName){
		LOGGER.info("Entering : getStockDataForEntity ",System.currentTimeMillis());
		stockDataService.fetchStockData(new StockName(stockName),StockService.TIME_SERIES_INTRADAY, TimeInterval.FIVE_MIN, OutputSize.COMPACT);
		LOGGER.info("Completed : getStockDataForEntity ",System.currentTimeMillis());
	}
	
}
