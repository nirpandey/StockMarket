package com.stockmarket.data.stockmarket.dao;

import java.util.List;

import com.stockmarket.data.stockmarket.model.StockData;
import com.stockmarket.data.stockmarket.request.OutputSize;
import com.stockmarket.data.stockmarket.request.StockName;
import com.stockmarket.data.stockmarket.request.StockService;
import com.stockmarket.data.stockmarket.request.TimeInterval;
import com.stockmarket.data.stockmarket.response.IntraDayResponse;

public interface IntraDayDao {

	public String fetchStockData(StockName stockName, StockService timeSeriesIntraday, TimeInterval fiveMin, OutputSize compact);
}
