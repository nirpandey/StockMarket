package com.stockmarket.data.stockmarket.request;

import com.stockmarket.data.stockmarket.parameters.StockDataParameter;

public class StockName implements StockDataParameter {
	
	private final String stockName;

	public StockName(String stockName) {
		super();
		this.stockName = stockName;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return "symbol";
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return stockName;
	}

}
