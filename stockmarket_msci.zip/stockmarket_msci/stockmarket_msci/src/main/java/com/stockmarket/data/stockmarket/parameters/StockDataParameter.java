package com.stockmarket.data.stockmarket.parameters;

public interface StockDataParameter {
	
	public String getKey();
	public String getValue();

}
