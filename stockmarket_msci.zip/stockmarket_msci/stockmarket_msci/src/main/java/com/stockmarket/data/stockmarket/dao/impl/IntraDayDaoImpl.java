package com.stockmarket.data.stockmarket.dao.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.stockmarket.data.stockmarket.connector.StockApiConnector;
import com.stockmarket.data.stockmarket.dao.IntraDayDao;
import com.stockmarket.data.stockmarket.request.OutputSize;
import com.stockmarket.data.stockmarket.request.StockName;
import com.stockmarket.data.stockmarket.request.StockService;
import com.stockmarket.data.stockmarket.request.TimeInterval;


@Component
public class IntraDayDaoImpl implements IntraDayDao {
	
	@Autowired
	private StockApiConnector apiConnector;
	
	private static final String BASE_URL = "https://www.alphavantage.co/query?";
	
	@Override
	public String fetchStockData(StockName stockName, StockService timeSeriesIntraday, TimeInterval fiveMin, OutputSize compact){
		
			  StringBuilder responseBuilder = new StringBuilder();
		try {
			  String url = apiConnector.getConnection(stockName,timeSeriesIntraday,fiveMin,compact);
		      URL request = new URL(BASE_URL + url);
		      URLConnection connection = request.openConnection();
		      InputStreamReader inputStream = new InputStreamReader(connection.getInputStream(), "UTF-8");
		      BufferedReader bufferedReader = new BufferedReader(inputStream);

		      String line;
		      while ((line = bufferedReader.readLine()) != null) {
		        responseBuilder.append(line);
		      }
		      bufferedReader.close();
		    } catch (IOException e) {
		    	e.printStackTrace();
		    }
			return responseBuilder.toString();
		
	}
}
