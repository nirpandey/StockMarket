package com.stockmarket.data.stockmarket.request;

import com.stockmarket.data.stockmarket.parameters.StockDataParameter;

public enum TimeInterval implements StockDataParameter {
	  ONE_MIN("1min"),
	  FIVE_MIN("5min"),
	  TEN_MIN("10min"),
	  FIFTEEN_MIN("15min"),
	  THIRTY_MIN("30min"),
	  SIXTY_MIN("60min");
	
	private final String timeInterval;
	
	TimeInterval(String timeInterval) {
		this.timeInterval = timeInterval;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return "interval";
	}
	
	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return timeInterval;
	}

}
