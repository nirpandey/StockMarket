package com.stockmarket.data.stockmarket.service;

import com.stockmarket.data.stockmarket.request.OutputSize;
import com.stockmarket.data.stockmarket.request.StockName;
import com.stockmarket.data.stockmarket.request.StockService;
import com.stockmarket.data.stockmarket.request.TimeInterval;

public interface StockDataService {

	void fetchStockData(StockName stockName, StockService timeSeriesIntraday, TimeInterval fiveMin, OutputSize compact);

}
