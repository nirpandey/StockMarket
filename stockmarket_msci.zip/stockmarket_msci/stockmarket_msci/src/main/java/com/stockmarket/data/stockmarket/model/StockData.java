package com.stockmarket.data.stockmarket.model;

import java.time.LocalDateTime;

public class StockData {
	
	  private final LocalDateTime dateTime;
	  private final Double open;
	  private final Double high;
	  private final Double low;
	  private final Double close;
	  private final Long volume;
	  
	public StockData(LocalDateTime dateTime, Double open, Double high, Double low, Double close, Long volume) {
		super();
		this.dateTime = dateTime;
		this.open = open;
		this.high = high;
		this.low = low;
		this.close = close;
		this.volume = volume;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public Double getOpen() {
		return open;
	}

	public Double getHigh() {
		return high;
	}

	public Double getLow() {
		return low;
	}

	public Double getClose() {
		return close;
	}

	public Long getVolume() {
		return volume;
	}


	public void display() {

		System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.printf("%-30s %-30s %-30s %-30s %-30s %-30s",getDateTime(),getOpen(),getHigh(),getLow(),getClose(),getVolume());
		System.out.println();
	}
	
	
	  
	  

}
