package com.stockmarket.data.stockmarket.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.stockmarket.data.stockmarket.controller.StockDataController;
import com.stockmarket.data.stockmarket.dao.IntraDayDao;
import com.stockmarket.data.stockmarket.model.StockData;
import com.stockmarket.data.stockmarket.request.OutputSize;
import com.stockmarket.data.stockmarket.request.StockName;
import com.stockmarket.data.stockmarket.request.StockService;
import com.stockmarket.data.stockmarket.request.TimeInterval;
import com.stockmarket.data.stockmarket.response.IntraDayResponse;
import com.stockmarket.data.stockmarket.service.StockDataService;
import com.stockmarket.data.stockmarket.util.IntraDayOpsUtility;

@Component
public class StockDataServiceImpl implements StockDataService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StockDataServiceImpl.class);
	
	@Autowired
	private IntraDayDao intraDayDao;
	
	@Autowired
	private IntraDayOpsUtility intraDayOpsUtil;
	
	@Override
	public void fetchStockData(StockName stockName, StockService timeSeriesIntraday, TimeInterval fiveMin, OutputSize compact) {
		// TODO Auto-generated method stub
		LOGGER.info("Entering: fetchStockData()",System.currentTimeMillis());
		String jsonData =null;
		jsonData = intraDayDao.fetchStockData(stockName,timeSeriesIntraday,fiveMin,compact);
		LOGGER.info("Entering: parse()",System.currentTimeMillis());
		IntraDayResponse intraDayResponse = parse(fiveMin,jsonData);
		LOGGER.info("Entering: displayStockData()",System.currentTimeMillis());
		List<StockData> sortList = displayStockData(intraDayResponse);
		LOGGER.info("Entering: sort()",System.currentTimeMillis());
		sort(sortList);
		LOGGER.info("Completed: fetchStockData()",System.currentTimeMillis());
	}

	private void sort(List<StockData> sortList) {
		// TODO Auto-generated method stub
		intraDayOpsUtil.sort(sortList);
	}

	private List<StockData> displayStockData(IntraDayResponse intraDayResponse) {
		// TODO Auto-generated method stub
		return intraDayOpsUtil.displayStockData(intraDayResponse);
	}

	private  IntraDayResponse parse(TimeInterval fiveMin, String jsonData) {
		// TODO Auto-generated method stub
		return intraDayOpsUtil.parse(fiveMin,jsonData);
	}

}
